# Pharmacophore AI Website

Responsive static website prototype for an AI-powered pharmaceutical supply-chain platform for hospital pharmacies.

Files: index.html, styles.css, app.js, assets/hero.png.

The dashboard and performance figures are illustrative demo data and should be validated/replaced before real-world use.

## Publish
GitHub Pages can publish static HTML/CSS/JS from a repository. See: https://docs.github.com/en/pages/quickstart
